v1 = float(input("digite um número: "))
v2 = float(input("digite um número: "))
f=lambda a,b: a*b
print(f(v1,v2))