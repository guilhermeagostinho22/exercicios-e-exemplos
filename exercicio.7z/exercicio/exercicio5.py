#funcao = lambda y: return y
#h = funcao(4)
#print(h)
#invalid syntax