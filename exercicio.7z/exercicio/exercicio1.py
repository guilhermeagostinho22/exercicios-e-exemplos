nome_idade = lambda nome, idade: print(nome, "possui",idade,"anos")
nome_digitado = str(input("digite seu nome: "))
idade_digitado = int(input("digite sua idade: "))
print(nome_idade(nome_digitado, idade_digitado))