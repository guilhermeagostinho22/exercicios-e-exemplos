def leiaint():
    try:
        insert=int(input("Insira um numero real inteiro: "))
    except ValueError:
        print("valor invalido, valor de A = 0")
leiaint()

    
    